import { motion, AnimatePresence } from 'framer-motion';
import React, { useCallback, useEffect, useState } from 'react';
import LogoImage from '../LogoImage';

interface PrivacyModalProps {
  isVisible: boolean;
  onAccept: () => void;
  onDecline: () => void;
}

const modalVariants = {
  hidden: { 
    opacity: 0,
    transition: { duration: 0.2 }
  },
  visible: { 
    opacity: 1,
    transition: { duration: 0.3 }
  }
};

const contentVariants = {
  hidden: { 
    scale: 0.95, 
    opacity: 0, 
    y: 20,
    transition: { duration: 0.2 }
  },
  visible: { 
    scale: 1, 
    opacity: 1, 
    y: 0,
    transition: { 
      type: 'spring',
      stiffness: 400,
      damping: 30,
      mass: 0.8 
    }
  }
};

const PrivacyModal = ({ isVisible, onAccept, onDecline }: PrivacyModalProps) => {
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => {
    if (isVisible) {
      setMounted(true);
    }
  }, [isVisible]);

  const handleClose = useCallback(() => {
    setMounted(false);
  }, []);

  return (
    <AnimatePresence mode="wait">
      {isVisible && mounted && (
        <motion.div
          variants={modalVariants}
          initial="hidden"
          animate="visible"
          exit="hidden"
          className="fixed inset-0 flex justify-center items-center bg-black/30 backdrop-blur-md z-[60]"
          style={{ 
            willChange: 'opacity',
            isolation: 'isolate'
          }}
        >
          <motion.div
            variants={contentVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
            className="bg-white/95 backdrop-blur-sm rounded-2xl w-[90%] max-w-[500px] p-6 sm:p-8 shadow-2xl flex flex-col items-center relative overflow-hidden"
            style={{ 
              willChange: 'transform, opacity',
              transform: 'translateZ(0)',
              backfaceVisibility: 'hidden'
            }}
          >
            {/* Effet de lumière optimisé */}
            <motion.div
              animate={{ 
                opacity: [0.4, 0.6, 0.4],
                background: [
                  'radial-gradient(circle at 30% -20%, rgba(255,235,235,0.4) 0%, transparent 70%)',
                  'radial-gradient(circle at 70% -20%, rgba(255,245,245,0.6) 0%, transparent 70%)',
                  'radial-gradient(circle at 30% -20%, rgba(255,235,235,0.4) 0%, transparent 70%)'
                ]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut"
              }}
              className="absolute inset-0 pointer-events-none opacity-60"
              style={{ 
                mixBlendMode: 'soft-light',
                willChange: 'opacity, background'
              }}
            />

            <LogoImage 
              variant="confidentiality" 
              className="mb-4 transform-gpu"
            />
            
            <h3 className="font-avantgarde text-2xl text-eatly-primary font-semibold tracking-tight mb-2 text-center">
              Confidentialité
            </h3>

            <div className="w-full h-px bg-gradient-to-r from-transparent via-eatly-primary/30 to-transparent my-2" />

            <p className="font-playfair text-base leading-relaxed text-eatly-text-primary mb-6 text-center max-w-[90%]">
              Eatly respecte votre vie privée. Voulez-vous partager des données d'utilisation anonymes pour améliorer votre expérience ?
            </p>

            <div className="flex gap-4 sm:flex-row flex-col w-full justify-center">
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-6 py-3 rounded-lg font-avantgarde text-base font-medium bg-gray-600/95 backdrop-blur-sm text-white min-w-[140px] hover:bg-gray-600 transition-colors shadow-lg hover:shadow-xl transform-gpu"
                onClick={onDecline}
              >
                Refuser
              </motion.button>
              
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-6 py-3 rounded-lg font-avantgarde text-base font-medium bg-eatly-primary/95 backdrop-blur-sm text-white min-w-[140px] hover:bg-eatly-primary transition-colors shadow-lg hover:shadow-xl transform-gpu"
                onClick={onAccept}
              >
                Accepter
              </motion.button>
            </div>

            <a 
              href="#" 
              className="font-playfair text-sm text-eatly-primary mt-4 hover:underline hover:text-eatly-accent transition-colors"
            >
              En savoir plus sur notre politique de confidentialité
            </a>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PrivacyModal;
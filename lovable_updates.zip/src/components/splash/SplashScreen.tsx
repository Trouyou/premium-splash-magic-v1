import React, { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import LogoImage from '../LogoImage';

interface SplashScreenProps {
  duration?: number;
  onComplete?: () => void;
}

const splashVariants = {
  initial: {
    opacity: 0,
    scale: 0.98
  },
  animate: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: [0.6, 0.01, -0.05, 0.95]
    }
  },
  exit: {
    opacity: 0,
    scale: 1.02,
    transition: {
      duration: 0.3,
      ease: "easeInOut"
    }
  }
};

const SplashScreen: React.FC<SplashScreenProps> = ({ 
  duration = 3000,
  onComplete
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();

  const handleComplete = useCallback(() => {
    if (onComplete) {
      onComplete();
    } else {
      navigate('/login');
    }
  }, [onComplete, navigate]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration]);

  return (
    <AnimatePresence mode="wait" onExitComplete={handleComplete}>
      {isVisible && (
        <motion.div
          variants={splashVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="splash-screen"
          style={{
            willChange: 'transform, opacity',
            isolation: 'isolate'
          }}
        >
          {/* Effet de lumière radiale */}
          <motion.div
            className="absolute inset-0 pointer-events-none"
            animate={{
              background: [
                'radial-gradient(circle at 50% 50%, rgba(255,235,235,0.3) 0%, transparent 70%)',
                'radial-gradient(circle at 50% 50%, rgba(255,245,245,0.5) 0%, transparent 70%)',
                'radial-gradient(circle at 50% 50%, rgba(255,235,235,0.3) 0%, transparent 70%)'
              ]
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }}
            style={{
              willChange: 'background',
              mixBlendMode: 'soft-light'
            }}
          />

          {/* Logo principal */}
          <div className="relative z-10">
            <LogoImage
              variant="splash"
              className="transform-gpu"
            />
          </div>

          {/* Particules d'ambiance */}
          <motion.div
            className="absolute inset-0 pointer-events-none"
            animate={{
              opacity: [0.3, 0.5, 0.3],
              scale: [1, 1.1, 1]
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }}
            style={{
              background: 'radial-gradient(circle at center, rgba(255,255,255,0.8) 0%, transparent 70%)',
              willChange: 'opacity, transform',
              mixBlendMode: 'overlay'
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default React.memo(SplashScreen); 
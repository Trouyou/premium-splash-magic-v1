import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import { useState, FC, useEffect, useCallback, useMemo } from 'react';
import React from 'react';

interface LogoImageProps {
  className?: string;
  variant?: 'default' | 'confidentiality' | 'splash' | 'login';
  lovableId?: string;
  priority?: boolean;
}

const ANIMATION_VARIANTS = {
  default: {
    initial: { 
      opacity: 0, 
      scale: 0.95,
      y: 10,
      filter: 'brightness(0.95) saturate(1) contrast(1.05)'
    },
    animate: { 
      opacity: 1, 
      scale: 1,
      y: 0,
      filter: 'brightness(1.02) saturate(1.1) contrast(1.1)',
      transition: {
        duration: 0.8,
        ease: [0.4, 0.0, 0.2, 1],
        filter: { duration: 1.2 }
      }
    },
    exit: { 
      opacity: 0,
      scale: 0.95,
      y: -5,
      filter: 'brightness(0.95) saturate(1) contrast(1.05)',
      transition: {
        duration: 0.3,
        ease: "easeOut"
      }
    }
  },
  splash: {
    initial: { 
      opacity: 0, 
      scale: 0.85,
      y: 20,
      rotate: -5,
      filter: 'brightness(0.95) saturate(1) contrast(1.05)'
    },
    animate: { 
      opacity: 1, 
      scale: [0.85, 1.05, 1],
      y: 0,
      rotate: 0,
      filter: 'brightness(1.02) saturate(1.1) contrast(1.1)',
      transition: {
        duration: 2,
        ease: [0.6, 0.01, -0.05, 0.95],
        scale: {
          duration: 2,
          times: [0, 0.5, 1],
          ease: "easeOut"
        },
        filter: { 
          duration: 2,
          ease: "easeOut"
        }
      }
    },
    exit: { 
      opacity: 0,
      scale: 1.1,
      y: -20,
      rotate: 5,
      filter: 'brightness(1.02) saturate(1.1) contrast(1.1)',
      transition: {
        duration: 0.7,
        ease: "easeInOut"
      }
    }
  },
  login: {
    initial: { 
      opacity: 0,
      y: -10
    },
    animate: { 
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  }
};

const LogoImage: FC<LogoImageProps> = ({ 
  className = '', 
  variant = 'default', 
  lovableId,
  priority = false 
}) => {
  const [imageError, setImageError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  const logoSrc = useMemo(() => {
    if (lovableId) {
      return `/lovable-uploads/${lovableId}.png`;
    }
    
    switch (variant) {
      case 'confidentiality':
      case 'login':
        return '/lovable-uploads/24f50b86-9d7d-412b-8a05-4ebb531f0b26.png';
      case 'splash':
        return '/lovable-uploads/Logo_Eatly_Original_TraitTransparent_1.png';
      default:
        return '/lovable-uploads/Logo_Eatly_Original_TraitTransparent_1.png';
    }
  }, [lovableId, variant]);

  const containerClasses = useMemo(() => {
    switch (variant) {
      case 'confidentiality':
        return 'w-full flex justify-center items-center py-2';
      case 'splash':
        return `w-full h-full flex justify-center items-center ${className}`;
      case 'login':
        return `flex justify-center items-center mb-8 ${className}`;
      default:
        return `w-full flex justify-center items-center py-8 sm:py-12 md:py-16 ${className}`;
    }
  }, [variant, className]);

  const imageContainerClasses = useMemo(() => {
    switch (variant) {
      case 'confidentiality':
        return 'relative w-[180px] sm:w-[200px] aspect-[3/1]';
      case 'splash':
        return 'relative w-[70%] max-w-[300px] sm:max-w-[400px] aspect-square will-change-transform';
      case 'login':
        return 'relative w-[180px] sm:w-[200px] aspect-[3/1]';
      default:
        return 'relative w-full max-w-[320px] sm:max-w-[400px] aspect-[1/1]';
    }
  }, [variant]);

  const imageSizes = useMemo(() => {
    switch (variant) {
      case 'confidentiality':
      case 'login':
        return "(max-width: 640px) 180px, 200px";
      case 'splash':
        return "(max-width: 640px) 300px, 400px";
      default:
        return "(max-width: 640px) 320px, 400px";
    }
  }, [variant]);

  const handleImageError = useCallback(() => {
    console.error('Erreur de chargement du logo');
    setImageError(true);
  }, []);

  const handleImageLoad = useCallback(() => {
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    setIsLoaded(false);
    const img = document.createElement('img');
    img.src = logoSrc;
    
    if (img.complete) {
      handleImageLoad();
    } else {
      img.onload = handleImageLoad;
      img.onerror = handleImageError;
    }

    return () => {
      img.onload = null;
      img.onerror = null;
    };
  }, [logoSrc, handleImageLoad, handleImageError]);

  const animationVariant = ANIMATION_VARIANTS[variant === 'confidentiality' ? 'default' : variant];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={containerClasses}
      style={{ willChange: 'opacity' }}
    >
      <AnimatePresence mode="wait">
        {imageError ? (
          <motion.div
            key="error"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-center p-4 bg-gray-100 rounded-lg"
            role="alert"
          >
            <p>Logo temporairement indisponible</p>
          </motion.div>
        ) : (
          <motion.div
            key="logo"
            variants={animationVariant}
            initial="initial"
            animate={isLoaded ? "animate" : "initial"}
            exit="exit"
            className={imageContainerClasses}
          >
            <Image
              src={logoSrc}
              alt="Logo Eatly - Une expérience culinaire unique"
              fill
              sizes={imageSizes}
              priority={priority || variant === 'splash'}
              quality={90}
              loading={priority ? "eager" : "lazy"}
              className="object-contain transform-gpu"
              onError={handleImageError}
              onLoad={handleImageLoad}
              style={{
                filter: 'drop-shadow(0px 20px 40px rgba(209, 27, 25, 0.2))',
                willChange: 'transform, opacity, filter'
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default React.memo(LogoImage);
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
		"./src/components/**/*.{js,ts,jsx,tsx,mdx}",
		"./src/app/**/*.{js,ts,jsx,tsx,mdx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				eatly: {
					primary: '#D11B19',    // Rouge vif
					secondary: '#9C1B1A',  // Rouge foncé
					light: '#EDE6D6',      // Beige premium
					accent: '#FF4B47',
					textPrimary: '#2D2D2D'
				},
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				},
				'eatly-primary': 'var(--eatly-primary)',
				'eatly-accent': 'var(--eatly-accent)',
				'eatly-text-primary': 'var(--eatly-text-primary)',
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'fade-in': {
                    '0%': {
                        opacity: '0',
                        transform: 'translateY(10px)'
                    },
                    '100%': {
                        opacity: '1',
                        transform: 'translateY(0)'
                    }
                },
                'fade-out': {
                    '0%': {
                        opacity: '1',
                        transform: 'translateY(0)'
                    },
                    '100%': {
                        opacity: '0',
                        transform: 'translateY(10px)'
                    }
                },
                'scale-in': {
                    '0%': {
                        transform: 'scale(0.95)',
                        opacity: '0'
                    },
                    '100%': {
                        transform: 'scale(1)',
                        opacity: '1'
                    }
                },
                'scale-out': {
                    from: { transform: 'scale(1)', opacity: '1' },
                    to: { transform: 'scale(0.95)', opacity: '0' }
                },
                'rotate-loader': {
                    '0%': {
                        transform: 'rotate(0deg)'
                    },
                    '100%': {
                        transform: 'rotate(360deg)'
                    }
                },
				'line-grow': {
					'0%': {
						transform: 'scaleX(0)',
						opacity: '0'
					},
					'100%': {
						transform: 'scaleX(1)',
						opacity: '1'
					}
				},
				fadeIn: {
					'0%': { opacity: '0' },
					'100%': { opacity: '1' },
				},
				slideUp: {
					'0%': { 
						opacity: '0',
						transform: 'translateY(20px)',
					},
					'100%': { 
						opacity: '1',
						transform: 'translateY(0)',
					},
				},
				pulseSubtle: {
					'0%, 100%': { 
						opacity: '1',
						transform: 'scale(1)',
					},
					'50%': { 
						opacity: '0.95',
						transform: 'scale(1.02)',
					},
				},
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'fade-in-up': 'fade-in 0.5s ease-out forwards',
                'fade-out-down': 'fade-out 0.5s ease-out forwards',
                'scale-in': 'scale-in 0.4s ease-out forwards',
                'scale-out': 'scale-out 0.4s ease-out forwards',
                'rotate-loader': 'rotate-loader 1.5s linear infinite',
				'line-grow': 'line-grow 0.6s ease-out forwards',
				'fade': 'fadeIn 0.3s ease-out',
				'slide-up': 'slideUp 0.3s ease-out',
				'pulse-subtle': 'pulseSubtle 2s ease-in-out infinite',
			},
			fontFamily: {
				'avantgarde': ['ITC Avant Garde Gothic Pro', 'sans-serif'],
				'playfair': ['Playfair Display', 'serif'],
			},
			backdropFilter: {
				'none': 'none',
				'blur': 'blur(8px)',
			},
			transitionTimingFunction: {
				'bounce-soft': 'cubic-bezier(0.4, 0.0, 0.2, 1)',
			},
		}
	},
	plugins: [
		require("tailwindcss-animate"),
		require('@tailwindcss/forms'),
		require('@tailwindcss/aspect-ratio'),
	],
	future: {
		hoverOnlyWhenSupported: true,
	},
} satisfies Config;
